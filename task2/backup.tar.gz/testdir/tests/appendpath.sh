#!/bin/bash

filename="users.csv"
echo $PWD

path=$PWD"/$filename"

echo $path
cat $path


